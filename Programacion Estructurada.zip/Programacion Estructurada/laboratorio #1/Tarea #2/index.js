//Dado un conjunto de números ingresados por el usuario, crear una función que tome un array como parámetro y retorne el segundo número más grande del conjunto. Debe haber como mínimo dos números para hacer la comparación.

function secondNumber(array) {
    if (array.length < 2) {
      return "No hay suficientes números para comparar.";
    }
  
    const arrayOrdenado = array.sort((a, b) => b - a);
  
    return array[1];
  }
  
  console.log(secondNumber([1, 2, 3, 4, 5])); // Debería imprimir 4
  console.log(secondNumber([10, 5, 20, 8])); // Debería imprimir 10
  console.log(secondNumber([100, 200, 300, 400])); // Debería imprimir 300
  console.log(secondNumber([19, 12, 3, 45, 51])); // Debería imprimir 45

